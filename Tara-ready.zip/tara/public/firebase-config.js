// Firebase web config for Tara (project: tara-137-5).
// These values only identify the app; access is protected by Firestore rules + Google sign-in.
window.TARA_FIREBASE = {
  apiKey: "AIzaSyAcgJYYfbPj9tu2sNMT3_4AAlGQFbS7ZSU",
  authDomain: "tara-137-5.firebaseapp.com",
  projectId: "tara-137-5",
  storageBucket: "tara-137-5.firebasestorage.app",
  messagingSenderId: "336651924414",
  appId: "1:336651924414:web:7febd576aaa9d2f1ab3fef"
};
