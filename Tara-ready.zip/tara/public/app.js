/* Tara - women's holistic health PWA. Offline-first; optional Firebase sync. */
const $ = s => document.querySelector(s);
const DAY = 864e5, pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const add = (s, n) => iso(new Date(parse(s).getTime() + n * DAY));
const diff = (a, b) => Math.round((parse(a) - parse(b)) / DAY);
const TODAY = () => iso(new Date());

const blank = () => ({ name: '', cycleLen: 28, periodLen: 5, periods: [], moods: {}, daily: {}, journal: [], jdraft: '', events: [], sleepUsual: null, wake: 7, sleepAt: 22, notif: false, remind: true, updated: 0 });
let S = blank(), user = null;
let jEdit = null, jOpen = null, eEdit = null;
let tab = 'home', sel = TODAY(), calMonth = new Date(), uid = null, db = null;
const day = d => (S.daily[d] = S.daily[d] || { water: 0, sleep: 0, steps: 0, symptoms: [], flow: '' });
function save() { if (!user) return; S.updated = Date.now(); localStorage.setItem('tara:' + user, JSON.stringify(S)); clearTimeout(save.t); save.t = setTimeout(cloudSave, 800); }
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2200); }

/* ---------- content ---------- */
const QUOTES = ['You are allowed to rest. Rest is productive too.', 'Your body is doing amazing things every single day.', 'Be as kind to yourself as you are to others.', 'You are strong, you are worthy, you are enough.', 'Small steps still move you forward.', 'Your feelings are valid, and so is your pace.', 'Strong women lift each other up, starting with themselves.', 'You bloom in your own time.', 'Today, choose progress over perfection.', 'You deserve the love you give so freely.', 'You are the author of your own beautiful story.', 'Healing, growing and glowing at your own pace.', 'Your body deserves kindness, rest and celebration.', 'You are loved more than you know.'];
const AFFIRM = ['I love and respect my body.', 'I am calm, capable and confident.', 'I choose peace over pressure.', 'I am growing at my own pace.'];
const MOODS = { happy: ['Happy', '😊'], cute: ['Cute', '🥰'], excited: ['Excited', '🤩'], calm: ['Calm', '😌'], angry: ['Angry', '😠'], surprised: ['Surprised', '😲'], sad: ['Sad', '😢'], shy: ['Shy', '😳'], sleepy: ['Sleepy', '🥱'], tired: ['Tired', '😩'], thinking: ['Thinking', '🤔'], love: ['Love', '😍'], playful: ['Playful', '😜'], cool: ['Cool', '😎'], confused: ['Confused', '😕'], grateful: ['Grateful', '🙏'] };
const ACT = { happy: 'Dance to a favourite song, call a friend, or take a sunny walk.', cute: 'Take a cute selfie, or wear something that makes you smile.', excited: 'Use that energy! Dance, plan something fun, or share the good news.', calm: 'Journal three good things, or try gentle yoga.', angry: 'Step outside for 10 minutes, try box breathing (4-4-4-4), and drink some water.', surprised: 'Take a deep breath and let it sink in. Write down what surprised you.', sad: 'Breathe slowly for 2 minutes, watch something comforting, talk to someone you trust.', shy: 'It is okay to feel shy. Message someone you trust, or enjoy some quiet time.', sleepy: 'Dim the lights, sip warm milk or herbal tea and head to bed a little early.', tired: 'Take a 20-minute nap or do slow stretching. Go to bed early tonight.', thinking: 'Jot your thoughts in your journal. Sorting them out on paper really helps.', love: 'Write a thank-you note or treat yourself to a warm drink.', playful: 'Do something silly and fun: a selfie, a dance break or a game with friends.', cool: 'Use this energy! Tackle the task you have been putting off.', confused: 'Pause and list what is unclear. Talk it through with a friend, or sleep on it.', grateful: 'Write down three things you are thankful for today.' };
const SYMP = ['Cramps', 'Headache', 'Bloating', 'Back pain', 'Fatigue', 'Mood swings', 'Cravings', 'Acne', 'Nausea'];
const OLDMOOD = { confident: 'cool', loved: 'love', dreamy: 'thinking' };
function migrate(o) {
  for (const d in o.moods || {}) if (OLDMOOD[o.moods[d]]) o.moods[d] = OLDMOOD[o.moods[d]];
  (o.journal || []).forEach(e => { if (OLDMOOD[e.mood]) e.mood = OLDMOOD[e.mood]; });
  return o;
}
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const JPROMPT = { happy: 'What made you smile today?', cute: 'What small thing made you feel cute or cosy today?', excited: 'What are you most excited about?', calm: 'Name three small things that felt peaceful today.', angry: 'What is bothering you? Write it all out, no filter.', surprised: 'What surprised you today, and how did it feel?', sad: 'It is okay to let it out. What is on your heart?', shy: 'What made you feel shy? What would you say if you felt braver?', sleepy: 'What would make tonight restful?', tired: 'What does your body need most right now?', thinking: 'What is on your mind? Put the thoughts on paper.', love: 'Who or what made you feel loved today?', playful: 'What was the silliest, most fun moment today?', cool: 'What are you proud of right now?', confused: 'What feels unclear? Write the questions down.', grateful: 'List three things you are grateful for.' };
const JDEFAULT = 'How was your day? Write a few lines, just for you.';
const jPrompt = () => JPROMPT[S.moods[TODAY()]] || JDEFAULT;
const CARE = {
  menstrual: { food: 'Iron-rich foods: spinach, dates, lentils, jaggery. Warm ginger tea eases cramps.', skin: 'Use gentle cleanser; skin is sensitive now. Stay hydrated.', hyg: 'Change pad every 4-6 hours (tampon max 8). Wash hands before and after.', ex: 'Light walking, child pose and cat-cow stretches. Heat pad for cramps.' },
  follicular: { food: 'Fresh fruit, eggs, sprouts, nuts. Energy is rising, so eat balanced meals.', skin: 'Skin glows now. Light moisturiser and sunscreen daily.', hyg: 'Keep a spare pad in your bag. Wear breathable cotton.', ex: 'Great time for cardio, dance and strength training.' },
  fertile: { food: 'Leafy greens, seeds, berries and plenty of water.', skin: 'Skin may get oily; cleanse twice a day.', hyg: 'Daily gentle intimate hygiene with plain water; avoid scented products.', ex: 'High energy. Try a brisk walk, cycling or a workout class.' },
  luteal: { food: 'Magnesium foods: banana, dark chocolate, oats, pumpkin seeds. Cut back on caffeine and salt.', skin: 'Breakouts are common. Do not pick; use a mild spot treatment.', hyg: 'Be ready for your period. Pack supplies.', ex: 'Yoga, pilates and slow walks. Prioritise 7-9 hours of sleep.' }
};
const LEARN = [
  ['PCOS / PCOD', 'A hormonal condition where ovaries may make extra androgens. Signs: irregular or missed periods, acne, excess facial hair, hair thinning, weight gain. Lifestyle (balanced food, exercise, sleep) helps a lot. See a doctor for diagnosis.'],
  ['Menstrual health', 'A typical cycle is 21-35 days, with periods lasting 2-7 days. Cycles can vary a little month to month. Tracking helps you notice your own normal.'],
  ['Hormones & mood', 'Oestrogen and progesterone rise and fall through the cycle and can affect energy, mood, sleep and appetite. PMS is common and manageable.'],
  ['Hygiene & reproductive health', 'Wash the external area with plain water, wear breathable cotton, change period products on time and avoid douching. Regular check-ups matter.'],
  ['When to see a doctor', 'Seek medical advice if: periods are absent 3+ months (and not pregnant), cycles under 21 or over 35 days, soaking a pad every hour, severe pain that stops daily life, bleeding between periods or after sex, periods heavy for 7+ days, or sudden big changes. For fainting, very heavy bleeding or severe pain, get urgent care.']
];

/* ---------- cycle maths ---------- */
function starts() { return S.periods.map(p => p.start).sort(); }
function cycleInfo() {
  const st = starts(), t = TODAY(); if (!st.length) return null;
  let len = S.cycleLen; if (st.length > 1) { const g = []; for (let i = 1; i < st.length; i++) g.push(diff(st[i], st[i - 1])); const r = g.slice(-4).filter(x => x >= 15 && x <= 60); if (r.length) len = Math.round(r.reduce((a, b) => a + b) / r.length); }
  const last = st.filter(s => s <= t).pop() || st[0], d = diff(t, last) + 1;
  let next = add(last, len); while (next < add(t, -10)) next = add(next, len);
  const ov = add(next, -14), fs = add(ov, -5), fe = add(ov, 1);
  const phase = d <= S.periodLen ? 'menstrual' : (t >= fs && t <= fe) ? 'fertile' : t < fs ? 'follicular' : 'luteal';
  return { last, d, len, next, ov, fs, fe, phase, toNext: diff(next, t) };
}
function forecast(n) { const ci = cycleInfo(); if (!ci) return []; const o = []; for (let i = 0; i < n; i++) { const start = add(ci.next, i * ci.len), ov = add(start, -14); o.push({ start, ov, fs: add(ov, -5), fe: add(ov, 1) }); } return o; }
const fmtS = d => parse(d).toLocaleDateString('en', { day: 'numeric', month: 'short' });
function upcomingCard(n = 6) {
  const ci = cycleInfo(); if (!ci) return '<div class="card"><b>🔮 Upcoming periods</b><p>Log your first period to see predictions.</p></div>';
  return `<div class="card"><b>🔮 Upcoming periods</b>${forecast(n).map(x => `<div class="between" style="margin-top:8px"><span>${fmtS(x.start)} - ${fmtS(add(x.start, S.periodLen - 1))}</span><small style="color:var(--soft)">${diff(x.start, TODAY()) >= 0 ? 'in ' + diff(x.start, TODAY()) + ' days' : (-diff(x.start, TODAY())) + ' days late'}</small></div>`).join('')}<p style="margin-top:10px">Based on your average cycle of ${ci.len} days. Estimates only.</p></div>`;
}
const plenChips = () => [2, 3, 4, 5, 6, 7].map(n => `<span class="chip ${S.periodLen === n ? 'on' : ''}" data-act="plen" data-v="${n}">${n} days</span>`).join('');
const PHASE = { menstrual: 'Period', follicular: 'Follicular', fertile: 'Fertile window', luteal: 'Luteal' };

/* ---------- stickers (your uploaded art) ---------- */
const FX = { happy: ['✨', '🌟'], cute: ['💗', '✨'], excited: ['🎉', '⭐'], calm: ['🍃', '🌸'], angry: ['💢', '💢'], surprised: ['❗', '✨'], sad: ['💧', ''], shy: ['💗', '🌸'], sleepy: ['💤', '💤'], tired: ['💤', ''], thinking: ['💭', '❓'], love: ['💗', '💖'], playful: ['⭐', '🎀'], cool: ['✨', '😎'], confused: ['❓', '💭'], grateful: ['🙏', '💗'] };
function mascot(m = 'happy', size = 150, tap = true) {
  const f = FX[m] || FX.happy;
  return `<div class="stk s-${m}" style="--sz:${size}px"${tap ? ' data-act="hop"' : ''}><img src="img/${m}.webp" alt="${m}" draggable="false"><span class="fx f1">${f[0]}</span><span class="fx f2">${f[1]}</span></div>`;
}
const hero = (size = 170) => `<div class="stk s-hero" style="--sz:${size}px" data-act="hop"><img src="img/u-hi.webp" alt="Tara" draggable="false"><span class="fx f1">💗</span><span class="fx f2">✨</span></div>`;
const PINFO = {
  menstrual: { icon: '🩸', name: 'Menstrual phase', hormones: 'Oestrogen and progesterone are at their lowest while your uterus sheds its lining.', feel: ['Cramps or lower-back ache', 'Tiredness, low energy', 'Bloating', 'Feeling emotional', 'Headaches', 'Comfort-food cravings'], tip: 'Rest, stay warm and drink plenty of water. Be gentle with yourself.' },
  follicular: { icon: '🌱', name: 'Follicular phase', hormones: 'Oestrogen is rising as your body prepares an egg.', feel: ['Rising energy', 'Better mood and focus', 'Clearer, glowing skin', 'More creative and social', 'Lighter appetite'], tip: 'A great time to start new things, plan and exercise.' },
  fertile: { icon: '🌸', name: 'Fertile window / ovulation', hormones: 'Oestrogen peaks and an egg is released around ovulation.', feel: ['Peak energy and confidence', 'Feeling more social', 'Mild one-sided pelvic twinge', 'Clear, stretchy discharge', 'Higher libido', 'Slight breast tenderness'], tip: 'Enjoy the energy, stay hydrated and keep moving.' },
  luteal: { icon: '🌙', name: 'Luteal phase', hormones: 'Progesterone rises, then hormones drop before your period if there is no pregnancy.', feel: ['Mood swings or irritability (PMS)', 'Bloating and water retention', 'Breast tenderness', 'Sweet or salty cravings', 'Tiredness, restless sleep', 'Acne breakouts', 'Mild cramps near the end'], tip: 'Prioritise sleep, magnesium-rich foods and slow movement like yoga.' }
};
function phaseCard(ci) {
  if (!ci) return '<div class="phase"><b>What phase are you in?</b><p>Log your period and Tara will show how each phase can make you feel.</p></div>';
  const p = PINFO[ci.phase], late = ci.toNext < 0 ? `<p class="late">Your period is ${-ci.toNext} day${ci.toNext === -1 ? '' : 's'} late. ${ci.toNext <= -7 ? 'If it is more than a week late, consider a pregnancy test or check with a doctor.' : 'Stress, sleep and travel can shift your cycle.'}</p>` : '';
  return `<div class="phase"><div class="between"><b>${p.icon} ${p.name}</b><small>Day ${ci.d}</small></div><p>${p.hormones}</p><p style="margin-top:8px"><b>You may be feeling:</b></p><div class="chips tr">${p.feel.map(f => `<span class="chip">${f}</span>`).join('')}</div><p class="mind">💡 ${p.tip}</p>${late}</div>`;
}

/* ---------- calendar events & reminders ---------- */
const ALERTS = [[-1, 'No alert'], [0, 'At the time'], [10, '10 min before'], [60, '1 hour before'], [1440, '1 day before']];
const REPEATS = [['none', 'No repeat'], ['daily', 'Every day'], ['weekly', 'Every week'], ['monthly', 'Every month'], ['yearly', 'Every year']];
function occursOn(ev, d) {
  if (d < ev.date) return false;
  switch (ev.repeat) {
    case 'daily': return true;
    case 'weekly': return diff(d, ev.date) % 7 === 0;
    case 'monthly': return parse(d).getDate() === parse(ev.date).getDate();
    case 'yearly': { const a = parse(d), b = parse(ev.date); return a.getDate() === b.getDate() && a.getMonth() === b.getMonth(); }
    default: return d === ev.date;
  }
}
const eventsOn = d => (S.events || []).filter(e => occursOn(e, d)).sort((a, b) => (a.time || '24').localeCompare(b.time || '24'));
const fmtTime = t => { const [h, m] = t.split(':').map(Number); return (h % 12 || 12) + ':' + pad(m) + ' ' + (h < 12 ? 'AM' : 'PM'); };
const evMeta = e => (e.time ? fmtTime(e.time) : 'All day') + (e.repeat && e.repeat !== 'none' ? ' · repeats' : '') + (e.alert >= 0 ? ' · 🔔' : '');
const evRow = e => `<div class="evr"><span class="evd"></span><div><b>${esc(e.title)}</b><small>${evMeta(e)}</small></div><button class="evx" aria-label="Edit" data-act="eedit" data-v="${e.id}">✎</button><button class="evx" aria-label="Delete" data-act="edel" data-v="${e.id}">🗑</button></div>`;
function todayEventsCard() {
  const ev = eventsOn(TODAY()); if (!ev.length) return '';
  return `<div class="card"><div class="between"><b>📅 Today's events</b><small class="lnk" data-act="tab" data-v="period">Calendar ›</small></div>${ev.map(e => `<div class="evr"><span class="evd"></span><div><b>${esc(e.title)}</b><small>${evMeta(e)}</small></div></div>`).join('')}</div>`;
}
function upcomingEventsCard() {
  const t = TODAY(), out = [];
  for (let i = 0; i <= 30 && out.length < 6; i++) { const d = add(t, i); eventsOn(d).forEach(e => out.push([d, e])); }
  if (!out.length) return '';
  return `<div class="card"><b>🔔 Coming up</b>${out.map(([d, e]) => `<div class="evr" data-act="sel" data-v="${d}" style="cursor:pointer"><span class="evd"></span><div><b>${esc(e.title)}</b><small>${i0(d)}${e.time ? ' · ' + fmtTime(e.time) : ''}</small></div></div>`).join('')}</div>`;
}
const i0 = d => d === TODAY() ? 'Today' : d === add(TODAY(), 1) ? 'Tomorrow' : fmtS(d);
function evTick() { // fires event alerts (while Tara is open)
  const now = new Date(), t = iso(now); let fired = {};
  try { fired = JSON.parse(localStorage.getItem('tara-evfired') || '{}'); } catch (e) { }
  for (const k in fired) if (now - fired[k] > 3 * DAY) delete fired[k];
  for (const d of [t, add(t, 1)]) for (const ev of eventsOn(d)) {
    if (ev.alert < 0) continue;
    const [h, m] = (ev.time || '09:00').split(':').map(Number), p = parse(d); p.setHours(h, m, 0, 0);
    const at = p.getTime() - ev.alert * 60000, key = user + ev.id + d + ':' + ev.alert;
    if (now.getTime() < at || now.getTime() - at > 36e5 || fired[key]) continue;
    fired[key] = now.getTime(); localStorage.setItem('tara-evfired', JSON.stringify(fired));
    const when = (d === t ? 'Today' : 'Tomorrow') + (ev.time ? ' at ' + fmtTime(ev.time) : '');
    if (document.visibilityState === 'visible') showAlert('event', { title: ev.title, body: when });
    else if (S.notif && Notification.permission === 'granted') navigator.serviceWorker.ready.then(reg => reg.showNotification(ev.title, { body: when, icon: 'icon-192.png', tag: 'tara-ev' + ev.id })).catch(() => new Notification(ev.title, { body: when }));
    return;
  }
}
function openSleep() {
  const old = $('#alertbox'); if (old) old.remove();
  const plan = planSleep(), cur = sleepInfo().h;
  const d = document.createElement('div'); d.id = 'alertbox'; d.dataset.k = 'sleeplog'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', 'Log sleep');
  d.innerHTML = `<div class="acard">${sceneSleep()}<h1>How long did you sleep?</h1><p>Last night, in hours. Tara remembers it until you change it.</p><div class="chips" style="justify-content:center;margin:12px 0 4px">${[5, 6, 7, 8, 9].map(h => `<span class="chip ${cur === h ? 'on' : ''}" data-act="sleepset" data-v="${h}">${h} h</span>`).join('')}</div><p style="margin-bottom:6px">Your schedule is ${plan} h (${S.sleepAt}:00 to ${S.wake}:00) <span class="lnk" data-act="sleepset" data-v="${plan}">use it</span></p><input id="slh" type="number" min="0" max="24" step="0.5" placeholder="Or type hours, e.g. 7.5" value="${cur || ''}"><div class="row acts"><button class="btn" data-act="sleepsave">Save</button><button class="btn ghost" data-act="alertclose">Close</button></div><p style="margin-top:10px;font-size:12px">Saved until you change it. <span class="lnk" data-act="sleepreset">Reset sleep</span></p></div>`;
  document.body.appendChild(d);
}

/* ---------- sleep (kept until you change or reset it) + suggestions ---------- */
const planSleep = () => S.sleepAt <= S.wake ? S.wake - S.sleepAt : 24 - S.sleepAt + S.wake;
function sleepInfo() {
  const d = (S.daily[TODAY()] || {}).sleep; if (d) return { h: d, src: 'today' };
  if (S.sleepUsual) return { h: S.sleepUsual, src: 'usual' };
  return { h: planSleep(), src: 'plan' };
}
const TIPS_SYMP = {
  'Cramps': ['🔥', 'Cramps: a warm water bag on your lower belly, ginger or chamomile tea and gentle stretches (child pose, cat-cow) can help.'],
  'Headache': ['💧', 'Headache: sip water, rest in a dim quiet room, do not skip meals and take a break from screens.'],
  'Bloating': ['🍵', 'Bloating: go easy on salty and fizzy food, try ginger or fennel tea and take a slow walk.'],
  'Back pain': ['🧘', 'Back pain: try cat-cow and child pose, use gentle heat and avoid sitting for long stretches.'],
  'Fatigue': ['🥬', 'Fatigue: eat iron-rich food (spinach, dates, lentils) with something sour like lemon, and plan a short nap.'],
  'Mood swings': ['📓', 'Mood swings: cut back on caffeine, get some sunlight and write a few lines in your journal.'],
  'Cravings': ['🍫', 'Cravings: pair something sweet with nuts or protein, and enjoy a small piece of dark chocolate.'],
  'Acne': ['🧴', 'Acne: wash gently twice a day, change your pillowcase often and do not pick at spots.'],
  'Nausea': ['🍋', 'Nausea: eat small light meals, sip ginger or lemon water and get fresh air. Avoid oily food.']
};
function suggestions() {
  const out = [], t = TODAY(), ci = cycleInfo(), dd = day(t), sy = [];
  for (let i = 0; i < 3; i++) { const d = S.daily[add(t, -i)]; if (d) d.symptoms.forEach(x => { if (!sy.includes(x)) sy.push(x); }); }
  if (dd.flow === 'Heavy') out.push(['🩸', 'Heavy flow: change your pad every 3-4 hours, drink extra fluids and eat iron-rich food. See a doctor if you soak a pad every hour.']);
  sy.slice(0, 3).forEach(x => TIPS_SYMP[x] && out.push(TIPS_SYMP[x]));
  if (sy.length >= 4) out.push(['👩‍⚕️', 'Several symptoms at once: rest well, and if they last or feel severe, please talk to a doctor.']);
  const logged = Object.keys(S.daily).filter(d => S.daily[d].sleep > 0).sort().slice(-3).map(d => S.daily[d].sleep);
  const si = sleepInfo(), h = logged.length ? Math.round(logged.reduce((a, b) => a + b) / logged.length * 10) / 10 : si.h, basis = logged.length ? 'You have been sleeping about ' + h + ' hours' : 'Your ' + (si.src === 'usual' ? 'usual' : 'planned') + ' sleep is ' + h + ' hours';
  if (h < 5) out.push(['😴', basis + ', which is very little. Aim for an earlier bedtime tonight, keep screens off for 30 minutes before bed and skip caffeine after noon.']);
  else if (h < 7) out.push(['🌙', basis + ', a bit short. Try going to bed 30 minutes earlier. Good sleep also eases PMS and cramps.']);
  else if (h <= 9) out.push(['🌙', basis + '. That is a healthy range, so keep your routine going!']);
  else out.push(['☀️', basis + ', which is quite long. If you still feel tired, try a morning walk, and see a doctor if it continues.']);
  if (ci) { const p = PINFO[ci.phase]; out.push([p.icon, p.name + ': ' + p.tip]); }
  if (hour() >= 14 && dd.water < 4) out.push(['💧', 'You have had ' + dd.water + ' of 8 glasses so far. Have a glass of water now.']);
  return out.slice(0, 6);
}
function suggestCard() {
  const dd = day(TODAY());
  return `<div class="card sugg"><div class="between"><b>💡 Tara's suggestions</b><small class="lnk" data-act="tab" data-v="care">Care tips ›</small></div>
<p style="margin:8px 0 6px">Feeling any of these today? Tap to add.</p><div class="chips">${SYMP.map(x => `<span class="chip ${dd.symptoms.includes(x) ? 'on' : ''}" data-act="hsymp" data-v="${x}">${x}</span>`).join('')}</div>
${suggestions().map(([e, t]) => `<div class="sg"><span>${e}</span><p>${esc(t)}</p></div>`).join('')}<small class="note">Based on your sleep, symptoms and cycle. Wellness tips, not medical advice.</small></div>`;
}
function calTease() {
  const t = TODAY(); let nx = null;
  for (let i = 0; i <= 30 && !nx; i++) { const e = eventsOn(add(t, i))[0]; if (e) nx = [add(t, i), e]; }
  const line = nx ? esc(nx[1].title) + ' · ' + i0(nx[0]) + (nx[1].time ? ' ' + fmtTime(nx[1].time) : '') : 'Add events and reminders, and log your period';
  return `<button class="jtease" data-act="tab" data-v="period"><span class="jt-ic">📅</span><span class="jt-tx"><b>Calendar &amp; period log</b><span>${line}</span></span><span class="jt-go">›</span></button>`;
}

/* ---------- cycle wheel ---------- */
const WC = { m: '#ef5b7b', f: '#5cc58a', fert: '#f6ae2d', ov: '#d6334a', l: '#4fa6ff' };
const polar = (c, r, deg) => { const a = deg * Math.PI / 180; return [c + r * Math.cos(a), c + r * Math.sin(a)]; };
function sector(c, r1, r2, a1, a2) {
  const [x1, y1] = polar(c, r2, a1), [x2, y2] = polar(c, r2, a2), [x3, y3] = polar(c, r1, a2), [x4, y4] = polar(c, r1, a1);
  return `M${x1.toFixed(1)} ${y1.toFixed(1)}A${r2} ${r2} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}L${x3.toFixed(1)} ${y3.toFixed(1)}A${r1} ${r1} 0 0 0 ${x4.toFixed(1)} ${y4.toFixed(1)}Z`;
}
function dayColor(i, L, P) { const ov = L - 14, fs = ov - 5, fe = ov + 1; return i <= P ? WC.m : i === ov ? WC.ov : i >= fs && i <= fe ? WC.fert : i < fs ? WC.f : WC.l; }
function arcPath(c, r, a1, a2, rev) {
  const [x1, y1] = polar(c, r, a1), [x2, y2] = polar(c, r, a2);
  return rev ? `M${x2.toFixed(1)} ${y2.toFixed(1)}A${r} ${r} 0 0 0 ${x1.toFixed(1)} ${y1.toFixed(1)}` : `M${x1.toFixed(1)} ${y1.toFixed(1)}A${r} ${r} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
}
function ring(ci) {
  const L = ci ? ci.len : S.cycleLen, P = Math.min(S.periodLen, L), d = ci ? Math.min(ci.d, L) : 0, C = 180, R1 = 112, R2 = 142, st = 360 / L, ov = L - 14, dim = ci ? 1 : .5;
  const ang = i => -90 + (i - 1) * st;
  let petals = '', segs = '', nums = '';
  for (let i = 1; i <= L; i++) {
    const col = dayColor(i, L, P), cur = i === d;
    petals += `<ellipse cx="${C}" cy="${C - 52}" rx="11" ry="46" fill="${col}" transform="rotate(${(ang(i) + st / 2 + 90).toFixed(1)} ${C} ${C})"/>`;
    const a1 = ang(i) + .9, a2 = ang(i) + st - .9, [tx, ty] = polar(C, 127, ang(i) + st / 2);
    segs += cur ? `<path class="cur" d="${sector(C, R1 - 6, R2 + 6, a1, a2)}" fill="${col}" stroke="#fff" stroke-width="3"/>` : `<path d="${sector(C, R1, R2, a1, a2)}" fill="${col}" opacity="${dim}"/>`;
    nums += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="${cur ? 14 : L > 31 ? 9 : 11}" font-weight="${cur ? 800 : 600}" fill="#fff">${i}</text>`;
  }
  const mA1 = ang(1), mA2 = ang(P) + st, oA1 = ang(ov) - st, oA2 = ang(ov) + 2 * st;
  const [ox, oy] = polar(C, 150, ang(ov) + st / 2);
  const outer = ci ? `<path id="wa1" d="${arcPath(C, 160, mA1, mA2)}" fill="none"/><path d="${arcPath(C, 152, mA1, mA2)}" stroke="${WC.m}" stroke-width="4" fill="none" stroke-linecap="round"/><text font-size="11" font-weight="600" fill="${WC.m}"><textPath href="#wa1" startOffset="50%" text-anchor="middle">menstruation (${P} days)</textPath></text>
<path id="wa2" d="${arcPath(C, 170, oA1, oA2, true)}" fill="none"/><path d="${arcPath(C, 152, oA1, oA2)}" stroke="${WC.ov}" stroke-width="4" fill="none" stroke-linecap="round"/><text font-size="11" font-weight="600" fill="${WC.ov}"><textPath href="#wa2" startOffset="50%" text-anchor="middle">ovulation</textPath></text><path d="M${ox.toFixed(1)} ${oy.toFixed(1)}l-5 -9h10z" fill="${WC.ov}" transform="rotate(${(ang(ov) + st / 2 + 90).toFixed(1)} ${ox.toFixed(1)} ${oy.toFixed(1)}) translate(0 -6)"/>` : '';
  return `<svg class="wheel" viewBox="0 0 360 360" role="img" aria-label="Cycle wheel"><g class="petals" style="mix-blend-mode:multiply" opacity=".55">${petals}</g><circle cx="${C}" cy="${C}" r="58" fill="#fff" fill-opacity=".92"/>${segs}${nums}${outer}</svg>`;
}
const wheelLegend = () => `<div class="wleg"><span><i style="background:${WC.m}"></i>Period</span><span><i style="background:${WC.f}"></i>Follicular</span><span><i style="background:${WC.fert}"></i>Fertile</span><span><i style="background:${WC.ov}"></i>Ovulation</span><span><i style="background:${WC.l}"></i>Luteal</span></div>`;

/* ---------- views ---------- */
function weekStrip() { const t = TODAY(), s = add(t, -3); let h = '<div class="week">'; for (let i = 0; i < 7; i++) { const d = add(s, i), p = parse(d); h += `<div class="wd ${d === t ? 'on' : ''}">${'SMTWTFS'[p.getDay()]}<b>${p.getDate()}</b></div>`; } return h + '</div>'; }
const hour = () => new Date().getHours();
function homeView() {
  const ci = cycleInfo(), t = TODAY(), dd = day(t), m = S.moods[t];
  const g = hour() < 12 ? 'Good morning' : hour() < 17 ? 'Good afternoon' : 'Good evening';
  const di = Math.floor(Date.now() / DAY), q = QUOTES[di % QUOTES.length], af = AFFIRM[di % AFFIRM.length];
  const sl = sleepInfo(), care = ci ? CARE[ci.phase] : CARE.follicular, goal = 8, nextRem = nextReminder(), fw = forecast(3).find(f => f.fe >= t);
  return `<div class="between"><div><h1>${g}${S.name ? ', ' + S.name : ''} 🌸</h1><p>${ci ? 'Day ' + ci.d + ' of your cycle' : 'Log your first period to begin'}</p></div><img class="logo-s" src="img/logo.webp" alt="Tara"></div>
<div class="special"><img class="sp-av" src="img/u-cheeks.webp" alt=""><div><small>💌 Today's special message</small><p class="sp-q">"${q}"</p><p class="sp-a">✨ ${af}</p></div><span class="spk k1">✨</span><span class="spk k2">💗</span><span class="spk k3">✨</span></div>
${weekStrip()}
<div class="card" style="text-align:center"><div class="ringwrap">${ring(ci)}<div class="mid"><small>${ci ? PHASE[ci.phase] : 'Welcome'}</small><big>${ci ? 'Day ' + ci.d : '--'}</big><small>${ci ? (ci.toNext >= 0 ? ci.toNext + ' days to period' : (-ci.toNext) + ' days late') : 'Log a period'}</small></div></div>${wheelLegend()}
<button class="btn" data-act="tab" data-v="period">${ci ? 'Period log' : 'Log period'}</button>${phaseCard(ci)}</div>
<div class="card" style="text-align:center">${m ? mascot(m, 200) : hero(190)}<div class="bubble">${m ? ACT[m] : 'Hi! Tap me, then tell me how you feel today 💕'}</div></div>
${journalTease()}${calTease()}
<div class="row"><div class="tile t1" data-act="tab" data-v="mood"><small>Today's mood</small><b>${m ? MOODS[m][1] + ' ' + MOODS[m][0] : 'Check in'}</b></div><div class="tile t2"><small>Next period</small><b>${ci ? fmtS(ci.next) : '--'}</b></div></div>
<div class="row" style="margin-top:12px"><div class="tile t3"><small>Fertile window</small><b>${fw ? fmtS(fw.fs) + ' - ' + fmtS(fw.fe) : '--'}</b></div><div class="tile t4" data-act="sleep" role="button" tabindex="0"><small>Sleep · ${sl.src === 'today' ? 'today' : sl.src === 'usual' ? 'usual' : 'planned'} ✎</small><b>${sl.h} hr</b></div></div>
${suggestCard()}
<div class="card"><div class="between"><b>💧 Water ${dd.water}/${goal} glasses</b><button class="btn" data-act="water">+1</button></div><div class="bar" style="margin-top:10px"><i style="width:${Math.min(100, dd.water / goal * 100)}%"></i></div></div>
${todayEventsCard()}${upcomingCard(3)}<div class="card"><b>⏰ Next reminder</b><p>${nextRem}</p><p>🚶‍♀️ Move breaks today: ${dd.moves || 0}</p></div>
<div class="card"><b>✨ Today for you</b><p><b>Eat:</b> ${care.food}</p><p><b>Move:</b> ${care.ex}</p></div><p class="foot">Tara is a wellness guide, not medical advice.</p>`;
}
function journalTease() {
  const last = S.journal[0], n = S.journal.length;
  const line = last ? '“' + esc(last.text.length > 70 ? last.text.slice(0, 70).trim() + '…' : last.text) + '”' : esc(jPrompt());
  return `<button class="jtease" data-act="tab" data-v="journal"><span class="jt-ic"><img src="img/u-book.webp" alt=""></span><span class="jt-tx"><b>My journal</b><span>${line}</span></span><span class="jt-go">${n ? '<em>' + n + '</em>' : ''}›</span></button>`;
}
function journalView() {
  const t = TODAY(), m = S.moods[t], ed = jEdit && S.journal.find(e => e.id === jEdit);
  const fmt = e => new Date(e.id).toLocaleDateString('en', { weekday: 'short', day: 'numeric', month: 'short' }) + ' · ' + new Date(e.id).toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' });
  const list = S.journal.map(e => {
    const open = jOpen === e.id;
    return `<div class="jent ${open ? 'open' : ''}"><div class="jh" data-act="jopen" data-v="${e.id}"><span class="jm">${e.mood && MOODS[e.mood] ? MOODS[e.mood][1] : '📝'}</span><small>${fmt(e)}</small><span class="jc">${open ? '⌃' : '⌄'}</span></div><p class="jx">${esc(e.text)}</p>${open ? `<div class="row jb"><button class="btn ghost" data-act="jedit" data-v="${e.id}">Edit</button><button class="btn ghost" data-act="jdel" data-v="${e.id}">Delete</button></div>` : ''}</div>`;
  }).join('');
  return `<button class="btn ghost jback" data-act="tab" data-v="home">‹ Home</button><div class="between"><h1>My journal 📓</h1><img class="jstk" src="img/u-book.webp" alt=""></div><p>Private to you. Saved on this device and in your account.</p>
<div class="card jcomp"><div class="between"><b>${ed ? 'Edit entry' : 'Write today'}</b>${m ? `<span class="chip" style="cursor:default">${MOODS[m][1]} ${MOODS[m][0]}</span>` : '<small style="color:var(--soft)">Tip: check in your mood first</small>'}</div>
<p class="jp">💭 ${esc(jPrompt())}</p><textarea id="jt" rows="5" maxlength="2000" placeholder="Start writing…">${esc(ed ? ed.text : S.jdraft || '')}</textarea>
<div class="row"><button class="btn" data-act="jsave">${ed ? 'Update entry' : 'Save entry'}</button>${ed ? '<button class="btn ghost" data-act="jcancel">Cancel</button>' : ''}</div></div>
<h2>${S.journal.length ? 'Past entries (' + S.journal.length + ')' : ''}</h2>${list || '<div class="card" style="text-align:center"><div style="font-size:34px">🌷</div><p>No entries yet. Your first page is waiting.</p></div>'}`;
}
function monthGrid() {
  const y = calMonth.getFullYear(), m = calMonth.getMonth(), first = new Date(y, m, 1).getDay(), n = new Date(y, m + 1, 0).getDate(), ci = cycleInfo(), t = TODAY();
  const fc = ci ? forecast(8) : [];
  const pdays = new Set(); S.periods.forEach(p => { const e = p.end || add(p.start, S.periodLen - 1); for (let d = p.start; d <= e; d = add(d, 1)) pdays.add(d); });
  let h = '<div class="cal">' + 'SMTWTFS'.split('').map(x => `<span>${x}</span>`).join('') + '<i></i>'.repeat(first);
  for (let i = 1; i <= n; i++) { const d = `${y}-${pad(m + 1)}-${pad(i)}`; let c = ''; if (pdays.has(d)) c = 'p'; else if (fc.some(f => d >= f.start && d < add(f.start, S.periodLen))) c = 'pp'; else if (fc.some(f => d >= f.fs && d <= f.fe)) c = 'f'; if (eventsOn(d).length) c += ' ev'; if (d === t) c += ' t'; if (d === sel) c += ' s'; h += `<b class="${c}" data-act="sel" data-v="${d}">${i}</b>`; }
  return h + '</div>';
}
function periodView() {
  const dd = day(sel), inP = S.periods.some(p => p.start <= sel && sel <= (p.end || add(p.start, S.periodLen - 1)));
  const evs = eventsOn(sel), ed = eEdit && S.events.find(e => e.id === eEdit);
  const opt = (list, cur) => list.map(([v, l]) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${l}</option>`).join('');
  return `<h1>Calendar</h1><div class="card"><div class="between"><button class="btn ghost" aria-label="Previous month" data-act="mon" data-v="-1">‹</button><b>${calMonth.toLocaleDateString('en', { month: 'long', year: 'numeric' })}</b><button class="btn ghost" aria-label="Next month" data-act="mon" data-v="1">›</button></div><br>${monthGrid()}
<p style="margin-top:10px">🟣 period · ⚪ predicted · 💜 fertile window · <span class="legdot"></span> event</p></div>
<div class="card"><div class="between"><b>${parse(sel).toLocaleDateString('en', { weekday: 'long', day: 'numeric', month: 'long' })}</b>${sel !== TODAY() ? '<span class="chip" data-act="sel" data-v="' + TODAY() + '">Today</span>' : ''}</div>
${evs.length ? evs.map(evRow).join('') : '<p style="margin-top:8px">Nothing planned for this day.</p>'}
<h2>${ed ? 'Edit event' : 'Add event or reminder'}</h2>
<label>What</label><input id="ev-t" maxlength="60" placeholder="e.g. Doctor visit, take iron tablet" value="${esc(ed ? ed.title : '')}">
<div class="row"><div><label>Date</label><input id="ev-d" type="date" value="${ed ? ed.date : sel}"></div><div><label>Time (optional)</label><input id="ev-tm" type="time" value="${ed ? ed.time : ''}"></div></div>
<div class="row"><div><label>Alert</label><select id="ev-a">${opt(ALERTS, ed ? ed.alert : 10)}</select></div><div><label>Repeat</label><select id="ev-r">${opt(REPEATS, ed ? ed.repeat : 'none')}</select></div></div>
<div class="row" style="margin-top:6px"><button class="btn" data-act="esave">${ed ? 'Update event' : 'Add to calendar'}</button>${ed ? '<button class="btn ghost" data-act="ecancel">Cancel</button>' : ''}</div>
<p style="margin-top:8px;font-size:12px">With no time, the alert comes at 9:00 AM. Alerts pop up while Tara is open; turn on phone alerts in Settings to also get them in the background.</p></div>
${upcomingEventsCard()}
<div class="card"><b>🩸 Period log</b><p>For ${parse(sel).toLocaleDateString('en', { day: 'numeric', month: 'long' })}</p><div class="row" style="margin:10px 0"><button class="btn" data-act="pstart">Period started</button><button class="btn ghost" data-act="pend">Period ended</button></div>${inP ? '<p>This day is in a logged period.</p>' : ''}
<h2>How many days does your period last?</h2><div class="chips">${plenChips()}</div><h2>Flow</h2><div class="chips">${['Light', 'Medium', 'Heavy'].map(f => `<span class="chip ${dd.flow === f ? 'on' : ''}" data-act="flow" data-v="${f}">${f}</span>`).join('')}</div>
<h2>Symptoms</h2><div class="chips">${SYMP.map(x => `<span class="chip ${dd.symptoms.includes(x) ? 'on' : ''}" data-act="symp" data-v="${x}">${x}</span>`).join('')}</div></div>
${upcomingCard(6)}`;
}
function moodView() {
  const t = TODAY(), m = S.moods[t];
  const hist = Object.keys(S.moods).sort().slice(-7).map(d => MOODS[S.moods[d]] ? `<span title="${d}" style="font-size:24px">${MOODS[S.moods[d]][1]}</span>` : '').join(' ');
  return `<h1>How are you feeling?</h1><div class="card" style="text-align:center">${m ? mascot(m, 210) : hero(170)}${m ? `<h2>${MOODS[m][0]}</h2>` : '<p>Tap a face below to check in</p>'}</div>
<div class="moods">${Object.keys(MOODS).map(k => `<div class="mood ${m === k ? 'on' : ''}" data-act="mood" data-v="${k}">${mascot(k, 76, false)}<span>${MOODS[k][0]}</span></div>`).join('')}</div>
${m ? `<div class="card"><b>Try this</b><p>${ACT[m]}</p></div>` : ''}<div class="card"><b>Last 7 check-ins</b><br>${hist || '<p>No check-ins yet.</p>'}</div>`;
}
function careView() {
  const ci = cycleInfo(), ph = ci ? ci.phase : 'follicular', c = CARE[ph], dd = day(TODAY());
  return `<h1>Care for you</h1><p>Phase: ${PHASE[ph]}</p><div class="card"><b>🥗 Nutrition</b><p>${c.food}</p></div><div class="card"><b>🧴 Skincare</b><p>${c.skin}</p></div><div class="card"><b>🌿 Hygiene</b><p>${c.hyg}</p></div><div class="card"><b>🧘 Exercise & relaxation</b><p>${c.ex}</p></div>
<div class="card"><b>😴 Sleep & activity (today)</b><label>Hours slept</label><input type="number" min="0" max="24" step="0.5" value="${dd.sleep || ''}" data-in="sleep"><label>Steps</label><input type="number" min="0" value="${dd.steps || ''}" data-in="steps"><p>Aim for 7-9 hours of sleep and about 6,000+ steps. Tara remembers your sleep until you change or reset it.</p><button class="btn ghost" data-act="sleepreset" style="margin-top:8px">Reset sleep</button></div>${suggestCard()}`;
}
function learnView() { return `<h1>Women's health</h1>` + LEARN.map(([t, b]) => `<div class="card"><b>${t}</b><p>${b}</p></div>`).join('') + '<p class="foot">Educational only. Please consult a doctor for medical concerns.</p>'; }
function settingsView() {
  return `<h1>Settings</h1><div class="card"><label>Your name</label><input id="nm" value="${S.name}"><label>Average cycle length (days)</label><input id="cl" type="number" value="${S.cycleLen}"><h2>Period length</h2><div class="chips">${plenChips()}</div>
<label style="display:block;margin-top:12px">Wake time (hour, 0-23)</label><input id="wk" type="number" value="${S.wake}"><label>Bedtime (hour, 0-23)</label><input id="sl" type="number" value="${S.sleepAt}"><button class="btn" data-act="saveset">Save</button></div>
<div class="card"><b>🔔 Reminders</b><p>Water every 2 hours, two walks a day, a stretch break and bedtime. A cute sticker animation pops up while Tara is open.</p>
<div class="row" style="margin:10px 0"><button class="btn" data-act="remind">${S.remind ? 'Pop-ups on ✓' : 'Pop-ups off'}</button><button class="btn ghost" data-act="notif">${S.notif ? 'Phone alerts on ✓' : 'Enable phone alerts'}</button></div>
<div class="row"><button class="btn ghost" data-act="prev" data-v="water">Preview 💧</button><button class="btn ghost" data-act="prev" data-v="walk">Preview 🚶‍♀️</button></div></div>
<div class="card"><b>👤 Account</b><p>${S.email || 'This device'}</p><p>${window.TARA_FIREBASE ? 'Signed in with Gmail. Your data is backed up privately in the cloud.' : 'Your data is saved on this device only.'}</p><button class="btn" data-act="logout">Sign out</button></div>
<div class="card"><button class="btn ghost" data-act="wipe">Delete all my data</button></div><p class="foot">Tara · created by VR</p>`;
}
function loginView() {
  const fb = !!window.TARA_FIREBASE;
  return `<div style="text-align:center;margin-top:16px"><img class="logo-l" src="img/logo.webp" alt="Tara logo"><h1>Welcome to Tara 🌸</h1><p>Your gentle health companion</p></div>
<div class="card" style="text-align:center">${fb ? '<button class="btn gbtn" data-act="gin"><b style="font-size:17px;color:#e255b4">G</b>&nbsp; Continue with Gmail</button><p style="margin-top:10px">One tap sign-in. Your data stays private and follows you across devices.</p>' : '<b>One-time setup</b><p>Gmail sign-in needs your free Firebase config. Paste it into <b>public/firebase-config.js</b> (steps in README.md) and refresh.</p><button class="btn ghost" data-act="dev" style="margin-top:12px">Try on this device for now</button>'}</div><p class="foot">Tara · created by VR</p>`;
}
const VIEWS = { journal: journalView, home: homeView, period: periodView, mood: moodView, care: careView, learn: learnView, settings: settingsView };
const NAV = [['home', '🏠'], ['period', '📅'], ['mood', '💗'], ['care', '🌿'], ['learn', '📖'], ['settings', '⚙️']];
function render() { $('#view').innerHTML = user ? VIEWS[tab]() : loginView(); $('#view').style.animation = 'none'; void $('#view').offsetWidth; $('#view').style.animation = ''; $('#nav').innerHTML = !user ? '' : NAV.map(([k, i]) => `<button aria-label="${k}" class="${tab === k || (k === 'home' && tab === 'journal') ? 'on' : ''}" data-act="tab" data-v="${k}">${i}</button>`).join(''); }

/* ---------- events ---------- */
function hearts(e) { for (let i = 0; i < 6; i++) { const h = document.createElement('div'); h.className = 'hearts'; h.textContent = ['💗', '💖', '✨', '🌸'][i % 4]; h.style.left = (e.clientX - 40 + Math.random() * 80) + 'px'; h.style.top = (e.clientY - 20) + 'px'; document.body.appendChild(h); setTimeout(() => h.remove(), 1400); } }
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]'); if (!el) return; const a = el.dataset.act, v = el.dataset.v, t = TODAY();
  if (a === 'dev' || a === 'gin') { auth(a); return; }
  if (a === 'alertclose') { closeAlert(); return; }
  if (a === 'alertok' || a === 'snooze') { const bx = $('#alertbox'), k = bx.dataset.k, ex = bx._ex; closeAlert(); if (a === 'snooze') { setTimeout(() => showAlert(k, ex), 6e5); toast('I will remind you in 10 minutes'); return; }
    if (k === 'water') { day(t).water++; toast('+1 glass 💧'); } else if (k === 'walk' || k === 'stretch') { day(t).moves = (day(t).moves || 0) + 1; toast('Great job! 🌸'); } else if (k === 'event') toast('Noted ✨'); save(); render(); return; }
  if (a === 'hop') { const m = el.closest('svg') || el; m.classList.remove('hop'); void m.getBoundingClientRect(); m.classList.add('hop'); setTimeout(() => m.classList.remove('hop'), 700); hearts(e); return; }
  if (a === 'sleep') { openSleep(); return; }
  if (a === 'sleepreset') { day(t).sleep = 0; S.sleepUsual = null; closeAlert(); toast('Sleep reset'); save(); render(); return; }
  if (a === 'hsymp') { const sy = day(t).symptoms, i = sy.indexOf(v); i < 0 ? sy.push(v) : sy.splice(i, 1); save(); render(); return; }
  if (a === 'sleepset' || a === 'sleepsave') {
    const h = a === 'sleepset' ? +v : parseFloat($('#slh').value);
    if (!(h > 0 && h <= 24)) return toast('Enter hours between 0 and 24');
    day(t).sleep = h; S.sleepUsual = h; closeAlert(); toast('Sleep saved 😴'); save(); render(); return;
  }
  if (a === 'eedit') { eEdit = +v; render(); const f = $('#ev-t'); if (f) { f.scrollIntoView({ block: 'center' }); f.focus(); } return; }
  if (a === 'ecancel') { eEdit = null; render(); return; }
  if (a === 'edel') { if (confirm('Delete this event?')) { S.events = S.events.filter(x => x.id !== +v); eEdit = null; save(); render(); toast('Event deleted'); } return; }
  if (a === 'esave') {
    const title = $('#ev-t').value.trim(), date = $('#ev-d').value, time = $('#ev-tm').value;
    if (!title) return toast('Add a title first 🌸'); if (!date) return toast('Pick a date');
    const o = { title, date, time, alert: +$('#ev-a').value, repeat: $('#ev-r').value };
    if (eEdit) { const x = S.events.find(e => e.id === eEdit); if (x) Object.assign(x, o); toast('Event updated'); }
    else { S.events.push(Object.assign({ id: Date.now() }, o)); toast(o.alert >= 0 ? 'Added with alert 🔔' : 'Added to calendar 📅'); }
    eEdit = null; sel = date; calMonth = parse(date); save(); render(); return;
  }
  if (a === 'jopen') { jOpen = jOpen === +v ? null : +v; render(); return; }
  if (a === 'jedit') { jEdit = +v; render(); $('#jt').focus(); return; }
  if (a === 'jcancel') { jEdit = null; render(); return; }
  if (a === 'jdel') { if (confirm('Delete this entry?')) { S.journal = S.journal.filter(x => x.id !== +v); jOpen = null; jEdit = null; save(); render(); toast('Entry deleted'); } return; }
  if (a === 'jsave') {
    const txt = $('#jt').value.trim(); if (!txt) return toast('Write something first 🌸');
    if (jEdit) { const x = S.journal.find(e => e.id === jEdit); if (x) { x.text = txt; x.edited = Date.now(); } jEdit = null; toast('Entry updated'); }
    else { S.journal.unshift({ id: Date.now(), date: t, text: txt, mood: S.moods[t] || '' }); S.jdraft = ''; hearts(e); toast('Saved to your journal 📓'); }
    save(); render(); return;
  }
  if (a === 'tab') { tab = v; jEdit = null; jOpen = null; eEdit = null; window.scrollTo(0, 0); }
  else if (a === 'sel') { sel = v; eEdit = null; }
  else if (a === 'mon') calMonth = new Date(calMonth.getFullYear(), calMonth.getMonth() + +v, 1);
  else if (a === 'water') { day(t).water++; if (day(t).water === 8) toast('Water goal reached! 💧'); }
  else if (a === 'mood') { S.moods[t] = v; toast('Mood saved ' + MOODS[v][1]); }
  else if (a === 'pstart') { if (!S.periods.some(p => p.start === sel)) S.periods.push({ start: sel }); toast('Period start logged'); }
  else if (a === 'pend') { const p = S.periods.filter(p => p.start <= sel).sort((x, y) => x.start < y.start ? -1 : 1).pop(); if (p) { p.end = sel; S.periodLen = Math.max(1, Math.min(10, diff(sel, p.start) + 1)); toast('Period end logged'); } }
  else if (a === 'flow') day(sel).flow = v;
  else if (a === 'symp') { const s = day(sel).symptoms, i = s.indexOf(v); i < 0 ? s.push(v) : s.splice(i, 1); }
  else if (a === 'saveset') { S.name = $('#nm').value.trim(); S.cycleLen = +$('#cl').value || 28; S.wake = +$('#wk').value; S.sleepAt = +$('#sl').value; toast('Saved'); }
  else if (a === 'notif') { enableNotif(); return; }
  else if (a === 'logout') { logout(); return; }
  else if (a === 'remind') S.remind = !S.remind;
  else if (a === 'prev') { showAlert(v); return; }
  else if (a === 'plen') S.periodLen = +v;
  else if (a === 'wipe') { if (confirm('Delete all your Tara data? This cannot be undone.')) { localStorage.removeItem('tara:' + user); S = blank(); cloudWipe(); } }
  save(); render();
});
document.addEventListener('input', e => { if (e.target.id === 'jt' && !jEdit) { S.jdraft = e.target.value; save(); } });
document.addEventListener('change', e => { const k = e.target.dataset.in; if (k) { day(TODAY())[k] = +e.target.value; if (k === 'sleep' && +e.target.value > 0) S.sleepUsual = +e.target.value; save(); toast('Saved'); } });

/* ---------- sticker scenes for reminders (same art as the mood stickers) ---------- */
const rep = (n, c) => Array.from({ length: n }, (_, i) => `<i class="${c} p${i + 1}"></i>`).join('');
const stkImg = (img, cls) => `<div class="sc-stk ${cls}"><img src="img/${img}.webp" alt="" draggable="false"></div>`;
const WAVE = 'M-64 0q16-7 32 0' + 't32 0'.repeat(7) + 'v120h-256z';
function sceneWater() {
  return `<div class="scn sc-water"><div class="sc-glow"></div><i class="rip r1"></i><i class="rip r2"></i>${rep(7, 'bub')}
${stkImg('u-cheeks', 'sip')}
<svg class="glass" viewBox="0 0 64 96" aria-hidden="true"><defs><clipPath id="gc"><path d="M9 8h46l-5 77a8 8 0 0 1-8 7H22a8 8 0 0 1-8-7z"/></clipPath><linearGradient id="gw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9ddcff"/><stop offset="1" stop-color="#4f8fff"/></linearGradient></defs>
<path d="M9 8h46l-5 77a8 8 0 0 1-8 7H22a8 8 0 0 1-8-7z" fill="#fff" fill-opacity=".55"/>
<g clip-path="url(#gc)"><g class="wlvl"><g class="wcounter"><g class="wave"><path d="${WAVE}" fill="url(#gw)"/></g><circle class="gb gb1" cx="26" cy="70" r="2.4" fill="#fff" fill-opacity=".7"/><circle class="gb gb2" cx="38" cy="76" r="1.8" fill="#fff" fill-opacity=".7"/><circle class="gb gb3" cx="32" cy="80" r="2.1" fill="#fff" fill-opacity=".7"/></g></g></g>
<path d="M9 8h46l-5 77a8 8 0 0 1-8 7H22a8 8 0 0 1-8-7z" fill="none" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M9 8h46l-5 77a8 8 0 0 1-8 7H22a8 8 0 0 1-8-7z" fill="none" stroke="#8cc8ee" stroke-width="1.2" stroke-linejoin="round"/><path d="M18 18l3 54" stroke="#fff" stroke-width="3.5" stroke-linecap="round" opacity=".75"/></svg>
${rep(4, 'dp')}<span class="fx2 x1">💧</span><span class="fx2 x2">✨</span><span class="fx2 x3">💙</span></div>`;
}
const TILE = '<g class="tr"><rect x="52" y="48" width="6" height="26" rx="3" fill="#b98a6c"/><circle cx="55" cy="40" r="19" fill="#ff9ed2"/><circle cx="46" cy="46" r="11" fill="#ffb7dc"/></g><g class="tr"><rect x="187" y="52" width="5" height="22" rx="2.5" fill="#b98a6c"/><circle cx="189" cy="45" r="15" fill="#c7b2ff"/><circle cx="182" cy="50" r="9" fill="#d9c9ff"/></g><g class="tr"><rect x="127" y="60" width="4" height="14" rx="2" fill="#b98a6c"/><circle cx="129" cy="56" r="10" fill="#9fe0c8"/></g>';
const dbl = t => t + `<g transform="translate(280)">${t}</g>`;
const FLOWERS = [20, 62, 105, 148, 190, 236].map((x, i) => `<g transform="translate(${x} ${8 + (i % 2) * 5})"><path d="M0 4v16" stroke="#6fcf97" stroke-width="2.5" stroke-linecap="round"/><circle r="4.5" fill="${['#ff7ab8', '#fff', '#ffd36b'][i % 3]}"/><circle r="2" fill="#ffb02e"/></g>`).join('');
function sceneWalk() {
  return `<div class="scn sc-walk"><div class="sun"></div><i class="cloud c1"></i><i class="cloud c2"></i>
<svg class="lay hills" viewBox="0 0 560 90" preserveAspectRatio="none" aria-hidden="true"><path d="M0 60q70-46 140 0t140 0t140 0t140 0v40H0z" fill="#e6d6ff"/></svg>
<svg class="lay trees" viewBox="0 0 560 90" preserveAspectRatio="none" aria-hidden="true">${dbl(TILE)}</svg>
${stkImg('u-peace', 'walk')}
<svg class="lay grass" viewBox="0 0 560 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 14q35-12 70 0t70 0t70 0t70 0t70 0t70 0t70 0t70 0v30H0z" fill="#9be7b5"/><path d="M0 24h560v20H0z" fill="#7ed6a0"/>${dbl(FLOWERS)}</svg>
<span class="fx2 x1">✨</span><span class="fx2 x2">💗</span><span class="fx2 x3">🌸</span></div>`;
}
function sceneStretch() {
  return `<div class="scn sc-stretch"><div class="sc-glow"></div><i class="ring r1"></i><i class="ring r2"></i><i class="ring r3"></i>${stkImg('excited', 'str')}<i class="ray a1"></i><i class="ray a2"></i><i class="ray a3"></i><i class="ray a4"></i><span class="fx2 x1">⭐</span><span class="fx2 x2">✨</span><span class="fx2 x3">🌟</span></div>`;
}
function sceneSleep() {
  return `<div class="scn sc-sleep"><i class="moon"></i>${rep(9, 'star')}${stkImg('u-sleepcat', 'zz')}<b class="z z1">z</b><b class="z z2">z</b><b class="z z3">Z</b></div>`;
}
function sceneEvent() {
  return `<div class="scn sc-event"><div class="sc-glow"></div>${rep(9, 'cf')}${stkImg('u-laugh', 'evs')}<span class="bell">🔔</span><span class="fx2 x1">✨</span><span class="fx2 x2">🎉</span></div>`;
}
function closeAlert() { const o = $('#alertbox'); if (o) { o.classList.add('out'); setTimeout(() => o.remove(), 220); } }
function showAlert(k, ex) {
  const old = $('#alertbox'); if (old) old.remove();
  const M = { water: [sceneWater(), 'Time to hydrate!', 'A glass of water keeps you glowing and eases cramps.', 'I drank water 💧'], walk: [sceneWalk(), 'Walk time!', 'Take a gentle 10-minute walk and move around.', 'I am moving! 🚶‍♀️'], stretch: [sceneStretch(), 'Stretch break', 'Stand up, reach high and loosen your shoulders.', 'Done ✨'], sleep: [sceneSleep(), 'Wind down', 'Time to get ready for bed. Sweet dreams!', 'Good night 🌙'], event: [sceneEvent(), ex ? esc(ex.title) : 'Event', ex ? esc(ex.body) : '', 'Got it ✨'] }[k];
  const d = document.createElement('div'); d.id = 'alertbox'; d.dataset.k = k; d._ex = ex; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', M[1].replace(/&[a-z#0-9]+;/g, ' '));
  d.innerHTML = `<div class="acard">${M[0]}<h1>${M[1]}</h1><p>${M[2]}</p><div class="row acts"><button class="btn" data-act="alertok">${M[3]}</button><button class="btn ghost" data-act="snooze">Later</button></div></div>`;
  document.body.appendChild(d);
  if (navigator.vibrate) try { navigator.vibrate(30); } catch (e) { }
}

/* ---------- reminders (water every 2h, 2 walks a day, stretch, sleep) ---------- */
function schedule() {
  const w = S.wake, s = S.sleepAt, span = s - w, o = [];
  for (let h = w + 1; h < s; h += 2) o.push({ h, m: 0, k: 'water', t: 'Time to hydrate! 💧', b: 'Have a glass of water.' });
  o.push({ h: w + Math.floor(span / 3), m: 30, k: 'walk', t: 'Walk time! 🚶‍♀️', b: 'Take a gentle 10-minute walk.' }, { h: w + Math.floor(2 * span / 3), m: 30, k: 'walk', t: 'Evening walk! 🚶‍♀️', b: 'A little stroll will lift your mood.' }, { h: 15, m: 15, k: 'stretch', t: 'Stretch break 🤸', b: 'Stand up, move around and stretch.' }, { h: s, m: 0, k: 'sleep', t: 'Wind down 🌙', b: 'Time to get ready for bed.' });
  return o.sort((a, b) => a.h * 60 + a.m - b.h * 60 - b.m);
}
function nextReminder() { const n = new Date(), nm = n.getHours() * 60 + n.getMinutes(), l = schedule(), r = l.find(x => x.h * 60 + x.m > nm) || l[0]; return `${r.t} at ${r.h}:${pad(r.m)}`; }
async function enableNotif() { if (!('Notification' in window)) return toast('Not supported here'); const p = await Notification.requestPermission(); S.notif = p === 'granted'; save(); render(); toast(S.notif ? 'Phone alerts enabled' : 'Permission denied'); }
function tick() {
  if (!user) return; evTick(); if (!S.remind) return; const n = new Date(), nm = n.getHours() * 60 + n.getMinutes();
  const r = schedule().find(x => { const d = nm - (x.h * 60 + x.m); return d >= 0 && d < 10; }); if (!r) return;
  const key = user + iso(n) + r.h + ':' + r.m; if (localStorage.getItem('tara-last') === key) return; localStorage.setItem('tara-last', key);
  if (document.visibilityState === 'visible') showAlert(r.k);
  else if (S.notif && Notification.permission === 'granted') navigator.serviceWorker.ready.then(reg => reg.showNotification(r.t, { body: r.b, icon: 'icon-192.png', tag: 'tara' })).catch(() => new Notification(r.t, { body: r.b }));
}
setInterval(tick, 30000); document.addEventListener('visibilitychange', tick);

/* ---------- accounts (Gmail via Firebase; device mode as fallback) ---------- */
function adoptOld(id) { // move earlier saved data into this account (once)
  const keys = ['tara'].concat(Object.keys(localStorage).filter(k => k.startsWith('tara:') && k !== 'tara:' + id));
  for (const k of keys) { const v = localStorage.getItem(k); if (v) { localStorage.removeItem(k); return v; } }
  return null;
}
function loadUser(id, info) {
  user = id; let d = localStorage.getItem('tara:' + id) || adoptOld(id), o = {};
  try { o = d ? JSON.parse(d) : {}; } catch (e) { }
  S = migrate(Object.assign(blank(), o));
  if (info) { S.email = info.email || S.email || ''; if (!S.name && info.displayName) S.name = info.displayName.split(' ')[0]; }
  localStorage.setItem('tara:' + id, JSON.stringify(S)); render();
  const ci = cycleInfo(); if (ci && ci.toNext >= 0 && ci.toNext <= 2) toast('Your period is expected in ' + ci.toNext + ' day(s)');
}
function auth(a) { if (a === 'gin') return signIn(); localStorage.setItem('tara-session', 'device'); loadUser('device'); }
function logout() { if (window.TARA_FIREBASE && window.firebase) firebase.auth().signOut(); localStorage.removeItem('tara-session'); user = null; uid = null; S = blank(); render(); }

/* ---------- optional Firebase (login + cloud backup) ---------- */
function load(src) { return new Promise(r => { const s = document.createElement('script'); s.src = src; s.onload = r; s.onerror = r; document.head.appendChild(s); }); }
async function initFB() {
  const v = 'https://www.gstatic.com/firebasejs/10.12.2/';
  await load(v + 'firebase-app-compat.js'); await load(v + 'firebase-auth-compat.js'); await load(v + 'firebase-firestore-compat.js');
  if (!window.firebase) return toast('Could not reach Firebase');
  firebase.initializeApp(window.TARA_FIREBASE); db = firebase.firestore();
  firebase.auth().onAuthStateChanged(async u => {
    if (!u) { uid = null; user = null; return render(); }
    uid = u.uid; loadUser(uid, u);
    try { const d = await db.collection('users').doc(uid).get(); if (d.exists && d.data().updated > S.updated) { S = migrate(Object.assign(blank(), d.data())); localStorage.setItem('tara:' + uid, JSON.stringify(S)); } else cloudSave(); } catch (e) { } render();
  });
}
const signIn = () => { const p = new firebase.auth.GoogleAuthProvider(); return firebase.auth().signInWithPopup(p).catch(e => { if (['auth/popup-blocked', 'auth/operation-not-supported-in-this-environment'].includes(e.code)) return firebase.auth().signInWithRedirect(p); if (e.code === 'auth/unauthorized-domain') toast('Add this domain in Firebase > Authentication > Settings > Authorized domains'); else if (e.code !== 'auth/popup-closed-by-user' && e.code !== 'auth/cancelled-popup-request') toast(e.message); }); };
function cloudSave() { if (db && uid) db.collection('users').doc(uid).set(JSON.parse(JSON.stringify(S))).catch(() => { }); }
function cloudWipe() { if (db && uid) db.collection('users').doc(uid).delete().catch(() => { }); }
async function boot() { if (window.TARA_FIREBASE) await initFB(); else { const s = localStorage.getItem('tara-session'); if (s) loadUser(s); } render(); tick(); }

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => { });
boot();
