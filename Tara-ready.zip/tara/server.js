// Zero-dependency static server. Run: npm start  ->  http://localhost:3000
const http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, 'public');
const types = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.svg':'image/svg+xml', '.webp':'image/webp', '.png':'image/png' };
http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.normalize(path.join(root, p));
  if (!f.startsWith(root)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': (types[path.extname(f)] || 'text/plain') + '; charset=utf-8' }); res.end(d);
  });
}).listen(process.env.PORT || 3000, () => console.log('Tara running at http://localhost:' + (process.env.PORT || 3000)));
