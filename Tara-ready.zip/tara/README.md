# Tara 🌸 – Women's Holistic Health App (lite PWA)

Period tracker · mood check-ins · daily motivation · health reminders · care tips · sleep & activity · women's health awareness · personalised dashboard.
Works offline, installs on Android like an app, and costs nothing. Zero npm dependencies.

## Run locally (Windows / any OS with Node.js)
```
cd tara
npm start
```
Open http://localhost:3000. On your phone (same Wi-Fi) open http://YOUR-PC-IP:3000, then Chrome menu > "Install app".

## Free deploy (Firebase Hosting)
```
npm i -g firebase-tools
firebase login
firebase init hosting     (choose existing project, public dir = public, SPA = No, don't overwrite files)
firebase deploy
```
You get a free https://YOUR-PROJECT.web.app link. Open it on Android > Install app (works like a Play Store app; a Play Store listing can wrap it later with Bubblewrap/TWA).
Alternatives: Netlify Drop or GitHub Pages (upload the `public` folder).

## Login (Gmail only)
Tara signs in with Google/Gmail through Firebase (free). One-time setup, about 5 minutes:
1. https://console.firebase.google.com > use your existing project (the one from Flutter Mail works) or create a new one.
2. Build > Authentication > Get started > Sign-in method > enable **Google**.
3. Build > Firestore Database > create (production mode).
4. Project settings (gear) > Your apps > Web (</>) > register app "Tara" > copy the config.
5. Paste it into `public/firebase-config.js` as `window.TARA_FIREBASE = { ... };` and refresh.
6. Rules: if the project is new, run `firebase deploy --only firestore:rules`. If you share the project with Flutter Mail, copy the `users/{uid}` block from `firestore.rules` into your existing rules instead, so nothing gets overwritten.
`localhost` is already an allowed domain. After deploying, add your `*.web.app` domain under Authentication > Settings > Authorized domains if it is not listed.
Your earlier data on this browser is moved into your Gmail account the first time you sign in, and backed up to Firestore.

## Notes
- Reminders (water every 2 h at :00, two light walks at :30 evenly spaced through your day, stretch, bedtime): a sticker-style animation (sipping water, walking through a meadow, stretching, sleeping) pops up when Tara is open, and a phone notification appears if alerts are enabled and Tara is in the background; browsers can't guarantee background alarms without a push server. Firebase Cloud Messaging can be added later.
- Predictions are estimates, not medical advice.
- Reminder popups reuse your sticker art (`loved`, `confident`, `playful`, `tired`) with CSS-only animation, so no extra files or libraries.
- Journal: Home > "My journal" card (below the mood sticker). Entries live in the same `users/{uid}` Firestore document as everything else, so no rules change is needed (Firestore's 1 MB document limit is roughly thousands of short entries).

- Sticker, hero and message images in `public/img` are the art you supplied. Check you have the right to use them before publishing on the Play Store; you can swap the files (same names) any time.

## Latest changes
- Mood stickers: 16-mood set (Happy, Cute, Excited, Calm, Angry, Surprised, Sad, Shy, Sleepy, Tired, Thinking, Love, Playful, Cool, Confused, Grateful). Old saved moods convert automatically.
- Cycle wheel on Home: numbered day ring coloured by phase, today highlighted.
- Sleep is remembered (logged today, else your usual, else your bedtime plan) until you reset it. Tap the Sleep tile on Home.
- Tara's suggestions on Home and Care: from sleep, today's symptoms (tap to add), flow and cycle phase.
- Calendar page (nav bar or the Calendar card on Home): month view, events and reminders with alerts and repeats, plus the period log.
- Logo is img/logo.webp; app icons are icon-192.png, icon-512.png, apple-touch-icon.png and favicon.png.
- Event alerts pop up while Tara is open (browsers cannot run alerts when an app is fully closed without a push server).
